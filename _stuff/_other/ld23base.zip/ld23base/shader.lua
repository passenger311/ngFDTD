--[[
  dgl/shader for luajit -- copyright (c) 2012 Gerry JJ <trick@icculus.org>

  This software is provided 'as-is', without any express or implied
  warranty. In no event will the authors be held liable for any damages
  arising from the use of this software.

  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

      1. The origin of this software must not be misrepresented; you must not
         claim that you wrote the original software. If you use this software
         in a product, an acknowledgment in the product documentation would be
         appreciated but is not required.

      2. Altered source versions must be plainly marked as such, and must not be
         misrepresented as being the original software.

      3. This notice may not be removed or altered from any source
         distribution.
--]]

require "util"
require "dgl"

local ffi = require "ffi"

local makeStringA = ffi.typeof("const char*[?]")
local makeGLintA = ffi.typeof("GLint[?]")
local makeGLcharA = ffi.typeof("GLchar[?]")

local _current_shader_program
local _shaderobjects = setmetatable({}, {__mode="k"})

local _glsltypes = {}
do
	for _,basetype in ipairs{ {"float","vec","mat"}, {"double","dvec","dmat"}, {"int","ivec"}, {"uint","uvec"}, {"bool","bvec"}, } do
		local base = basetype[1]
		local int = base ~= "float" and base ~= "double"
		_glsltypes[base] = { name = base, base = base, int = int, dim = 1, fulldim = 1 }
		if basetype[2] then
			for dim = 2, 4 do
				local vectype = basetype[2]..dim
				_glsltypes[vectype] = { name = vectype, base = base, int = int, parent = base, dim = dim, fulldim = dim }
				if basetype[3] then
					local mattype = basetype[3]..dim
					_glsltypes[mattype] = { name = mattype, base = base, int = int, parent = vectype, dim = dim, fulldim = dim*dim }
					for mrows = 2, 4 do
						local mattype2 = mattype .. "x" .. mrows
						_glsltypes[mattype2] = { name = mattype2, base = base, int = int, parent = basetype[2]..mrows, dim = dim, fulldim = dim*mrows }
					end
				end
			end
		end
	end
	for samptype in ipairs{ "1D", "2D", "3D", "Cube", "Buffer",
			"1DShadow", "2DShadow", "2DRect", "2DRectShadow",
			"1DArray", "2DArray", "1DArrayShadow", "2DArrayShadow",
			"2DMS", "2DMSArray",
	} do
		local name = "sampler" .. samptype
		_glsltypes[name] = { name = name, base = "int", int = true, dim = 1, fulldim = 1, sampler = true }
	end
end

local function getShaderInfo (src)
	src = src:gsub("/%*.-%*/", ""):gsub("//.-\n", "\n"):gsub("#.-\n", "\n")
	local info = {
		type = src:find("gl_Position", 1, true) and "GL_VERTEX_SHADER" or
				src:find("gl_FragColor", 1, true) and "GL_FRAGMENT_SHADER",
		attributes = {},
		uniforms = {},
	}
	for stmt in src:gmatch("[^;]+;") do
		local words = {}
		for word in stmt:gmatch("%S+") do
			if word ~= "lowp" and word ~= "mediump" and word ~= "highp" then
				words[#words+1] = word
			end
		end
		local varqual = words[1]
		if varqual == "in" and info.type == "GL_VERTEX_SHADER" then
			varqual = "attribute"
		end
		if varqual == "attribute" or varqual == "uniform" then
			local vartype = words[2]
			local varname,vardim = words[3]:match("[%w_]+%[%d+%]")
			if not varname then
				varname = words[3]:match("[%w_]+")
				vardim = 1
			end
			info[varqual.."s"][varname] = { name = varname, type = vartype, dim = vardim }
		end
	end
	return info
end

local function getLog (name, obj, logtype)
	local getfn = "glGet"..logtype.."iv"
	local getlogfn = "glGet"..logtype.."InfoLog"
	local loglen = makeGLintA(1)
	gl[getfn](obj, gl.GL_INFO_LOG_LENGTH, loglen)
	loglen = loglen[0]
	if loglen > 1 then
		local log = makeGLcharA(loglen)
		gl[getlogfn](obj, loglen, nil, log)
		log = ffi.string(log, loglen-1)
		print(logtype .. " \"" .. name .. "\" (" .. obj .. "):")
		print(log)
		return log
	end
end

function ShaderObject (name, src, oneshot)
	oneshot = not not oneshot
	if not src then
		src = name
		name = "untitled"
	end

	local function create (self)
		if self._obj then return self._obj end
		local obj = gl.glCreateShader(gl[self.info.type])
		self.obj = obj
		local srcstr = makeStringA(1)
		srcstr[0] = self.src
		gl.glShaderSource(obj, 1, srcstr, nil)
		return obj
	end

	local function compile (self)
		local obj = self._obj or create(self)
		gl.glCompileShader(obj)
		self.log = getLog(self.name, obj, "Shader")
		local status = makeGLintA(1)
		gl.glGetShaderiv(obj, gl.GL_COMPILE_STATUS, status)
		self._ready = status[0] ~= 0
		return obj
	end

	local function getObject (self)
		return self._ready and self._obj or compile(self)
	end

	local function deleteObject (self)
		local obj = self._obj
		if obj and obj ~= 0 then
			gl.glDeleteShader(self._obj)
		end
		self._obj = false
		self._ready = false
	end

	local obj = { name = name, src = src, oneshot = oneshot, info = getShaderInfo(src), _obj = false, _ready = false,
		getObject = getObject,
		deleteObject = deleteObject,
	}
	_shaderobjects[obj] = true
	return obj
end

function ShaderProgram (name, ...)
	local function create (self)
		if self._prg then return self._prg end
		local prg = gl.glCreateProgram()
		local uniforms, attrs = {}, {}
		self._uniforms, self._attributes = uniforms, attributes
		local glAttachShader = gl.glAttachShader
		for shobj,owned in pairs(self._shobjs) do
			local obj = shobj:getObject()
			glAttachShader(prg, obj)
			if owned then
				shobj:deleteObject()
			end
			for uname,uinfo in pairs(shobj.info.uniforms) do
				if uniforms[uname] then
					for k,v in pairs(uniforms[uname]) do
						if uinfo[k] ~= v then
							gl.glDeleteProgram(prg)
							error("uniform mismatch")
						end
					end
				else
					local u = {}
					uniforms[uname] = u
					u.name = uinfo.name
					u.type = uinfo.type
					u.dim = uinfo.dim
				end
			end
			for aname,ainfo in pairs(shobj.info.attributes) do
				local a = {}
				attrs[aname] = a
				a.name = ainfo.name
				a.type = ainfo.type
				a.dim = ainfo.dim
			end
		end
		self._prg = prg
		return prg
	end

	local function link (self)
		local prg = self._prg or create(self)
		local glBindAttribLocation = gl.glBindAttribLocation
		for name,index in pairs(self._bindattrib) do
			glBindAttribLocation(prg, index, name)
		end
		gl.glLinkProgram(prg)
		self.log = getLog(self.name, prg, "Program")
		local status = makeGLintA(1)
		gl.glGetProgramiv(prg, gl.GL_LINK_STATUS, status)
		local ready = status[0] ~= 0
		self._ready = ready
		if ready then
			for uname,uinfo in pairs(self._uniforms) do
				uinfo.loc = gl.glGetUniformLocation(prg, uname)
			end
		end
		return prg
	end

	local function getProgram (self)
		return self._ready and self._prg or link(self)
	end

	local function deleteProgram (self)
		local prg = self._prg
		if prg and prg ~= 0 then
			gl.glDeleteProgram(self._prg)
		end
		self._prg = false
		self._ready = false
	end

	local function bindAttribLocation (self, index, name)
		self._bindattrib[name] = index
		self._ready = false
	end

	local function use (self)
		if _current_shader_program ~= self then
			_current_shader_program = self
			gl.glUseProgram(getProgram(self))
		end
	end

	local function attach (self, shobj, own)
		local shobjs = self._shobjs or {}
		self._shobjs = shobjs
		if type(shobj) == "string" then
			shobj = ShaderObject(self.name .. #self._shobjs, shobj, true)
		end
		if own == nil then
			own = shobj.oneshot
		end
		shobjs[shobj] = not not own
	end

	local function setUniform (self, name, ...)
		local nargs = #{...}
		use(self)
		local info = self._uniforms[name]
		gl["glUniform" .. nargs .. (info.type.int and "i" or "f")](info.loc, ...)
	end

	local prg = { name = name, _prg = false, _ready = false, _bindattrib = {}, _binduniform = {},
		getProgram = getProgram,
		deleteProgram = deleteProgram,
		bindAttribLocation = bindAttribLocation,
		use = use,
		attach = attach,
		setUniform = setUniform,
		uniform = setmetatable({}, {__index = function (t,k) return getUniform(t,k) end, __newindex = function(t,k,v) return setUniform(t,k,v) end})
	}

	for shobj in ipairs{...} do
		prg:attach(shobj)
	end

	return prg
end

--[=[
local test = [[
attribute float hello;
uniform vec2 pos;

void main ()
{
	gl_Position = vec4(pos, 0.0, 1.0);
}
]]

print(serialize(getShaderInfo(test)))
--]=]
