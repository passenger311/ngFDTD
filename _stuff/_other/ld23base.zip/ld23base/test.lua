require "sdl"
require "dgl"
require "shader"
require "util"
local ffi = require "ffi"

local shader

local function init ()
	if sdl.SDL_Init(sdl.SDL_INIT_EVERYTHING) < 0 then
		error("couldn't init SDL")
	end
	atexit(function () sdl.SDL_Quit() end)

	sdl.SDL_GL_LoadLibrary(nil)
	gl.init(sdl.SDL_GL_GetProcAddress)
	atexit(function () gl.uninit() end)

	sdl.SDL_GL_SetAttribute(sdl.SDL_GL_DOUBLEBUFFER, 1)
	sdl.SDL_GL_SetAttribute(sdl.SDL_GL_SWAP_CONTROL, 1)

	if sdl.SDL_SetVideoMode(512, 512, 0, sdl.SDL_OPENGL) == nil then
		error("couldn't set videomode")
	end
	sdl.SDL_WM_SetCaption("Test", nil)

	gl.glViewport(0, 0, 512, 512)
	gl.glClearColor(0, 0, 0.5, 1)
	gl.glClear(gl.GL_COLOR_BUFFER_BIT)
	sdl.SDL_GL_SwapBuffers()

	local prg = ShaderProgram("shader")
	shader = prg
	prg:attach [[
attribute vec2 a_pos;
varying vec2 v_pos;
uniform float u_turns;

const float pi = 3.14159265358979323846;

void main ()
{
	float rad = u_turns * pi;
	float ct = cos(rad), st = sin(rad);
	vec2 rpos = mat2(ct, st, -st, ct) * a_pos;
	gl_Position = vec4(rpos, 0.0, 1.0);
	//gl_Position = ftransform();
	v_pos = gl_Position.xy;
}
]]
	prg:attach [[
uniform vec3 u_color1;
uniform vec3 u_color2;
varying vec2 v_pos;

void main ()
{
	gl_FragColor = vec4(mix(u_color1, u_color2, (v_pos.y + 0.5)), 1.0);
}
]]
	prg:bindAttribLocation(0, "a_pos")

	local verts = {
		-0.5,  0.5,
		-0.5, -0.5,
		 0.5,  0.5,
		 0.5, -0.5
	}
	gl.glVertexAttribPointer(0, 2, gl.GL_FLOAT, gl.GL_FALSE, 0, ffi.new("GLfloat[8]", verts))
	gl.glEnableVertexAttribArray(0);

	prg:use()
	prg:setUniform("u_color1", 0.0, 1.0, 0.0)
	prg:setUniform("u_color2", 1.0, 1.0, 0.0)
end

local _turns = 0
local function tick ()
	_turns = (_turns + (1.0 / 256.0)) % 1.0
	shader:setUniform("u_turns", _turns)
end

local function draw ()
	gl.glClear(gl.GL_COLOR_BUFFER_BIT)
	gl.glDrawArrays(gl.GL_TRIANGLE_STRIP, 0, 4)
	sdl.SDL_GL_SwapBuffers()
end

local function getTicks ()
	local ticks = sdl.SDL_GetTicks()
	return ticks
end

local function main ()
	init()
	local ev = ffi.new("SDL_Event[1]")
	local trigger = 0
	local tickhz = 100
	local prevticks = getTicks()

	while true do
		while sdl.SDL_PollEvent(ev) ~= 0 do
			local e = ev[0]
			local etype = e.type
			if etype == sdl.SDL_QUIT then
				return
			elseif etype == sdl.SDL_KEYDOWN then
				if e.key.keysym.sym == sdl.SDLK_ESCAPE then
					return
				end
			end
		end

		local curticks = getTicks()
		trigger = trigger + tickhz * (curticks - prevticks)
		prevticks = curticks
		while trigger >= 1000 do
			trigger = trigger - 1000
			tick()
		end
		draw()
	end
end

main()
