--[[
  lua/luajit extras -- copyright (c) 2012 Gerry JJ <trick@icculus.org>

  This software is provided 'as-is', without any express or implied
  warranty. In no event will the authors be held liable for any damages
  arising from the use of this software.

  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

      1. The origin of this software must not be misrepresented; you must not
         claim that you wrote the original software. If you use this software
         in a product, an acknowledgment in the product documentation would be
         appreciated but is not required.

      2. Altered source versions must be plainly marked as such, and must not be
         misrepresented as being the original software.

      3. This notice may not be removed or altered from any source
         distribution.
--]]

local ffi = require "ffi"

function gcrun (fn)
	return ffi.gc(ffi.new("char[1]"), fn)
end

function CallbackStack ()
	local fns = {
		add = function (self, fn)
			self[#self+1] = fn
		end,
		run = function (self)
			for i=#self, 1, -1 do
				self[i]()
				self[i] = nil
			end
		end,
		clear = function (self)
			for i=#self, 1, -1 do
				self[i] = nil
			end
		end,
	}
	fns._gc = gcrun(fns.run)
	return fns
end

local _atexit = CallbackStack()
function atexit (fn)
	_atexit:add(fn)
end

local nop = function () end

string.at = function (s, index)
	return s:sub(index, index)
end

string.byteat = function (s, index)
	return s:byte(index, index)
end

string.trim = function (s)
	return s:gsub("^%s*(.-)%s*$", "%1")
end

string.lines = function (s)
	if s:at(#s) ~= "\n" then
		s = s .. "\n"
	end
	return s:gmatch("(.-)\r?\n")
end

string.split = function (s, sep)
	sep = sep or "%s+"
	local result = {}
	local pos = 1
	local function addpart (to)
		local part = s:sub(pos, to)
		if #part > 0 then
			result[#result + 1] = part
		end
	end
	while pos < #s do
		local ns, ne = s:find(sep, pos)
		if not ns then break end
		if ns > pos then
			addpart(ns - 1)
		end
		pos = ne + 1
	end
	addpart(-1)
	return result
end

string.open = function (s, mode)
	mode = mode or "r"
	local iostr = {
		_str = s,
		_pos = 1,
		_len = #s,
		close = nop,
		flush = nop,
		lines = function (s)
			return s._str:lines()
		end,
		read = function (s, ...)
			if type(s._str) == "table" then
				s._str = table.concat(s._str)
			end
			if s._pos > s._len then return end
			local args = {...}
			local results = {}
			if #args == 0 then
				args = { "*l" }
			end
			for _,arg in ipairs(args) do
				if arg:at(1) == "*" then
					if arg == "*l" then
						if not s._lstr then
							s._lstr = s._str
							if s._lstr:at(#s._lstr) ~= "\n" then
								s._lstr = s._lstr + "\n"
							end
						end
						local line,npos = s._lstr:match("^(.-)\r?\n()", s._pos)
						results[#results+1] = line
						s._pos = npos or #s._str + 1
					elseif arg == "*a" then
						results[#results+1] = s._str:sub(s._pos)
						s._pos = #s._str + 1
					elseif arg == "*n" then
						local numlen = 0
						local num
						if s:at(s._pos) == "0" then
							numlen = 1
							num = tonumber(s:sub(s._pos, s._pos+3))
							if num then
								numlen = 3
							else
								num = 0
							end
						end
						for i=numlen,#s._str do
							local tmp = tonumber(s:sub(s._pos, s._pos + i))
							if not tmp then
								break
							end
							num = tmp
							numlen = i
						end
						results[#results+1] = num
						s._pos = s._pos + numlen + 1
					else
						error("invalid format")
					end
				else
					local epos = math.min(s._pos + tonumber(arg), #s._pos)
					results[#results+1] = s._str:sub(s._pos, epos)
					s._pos = epos + 1
				end
				if s._pos > #s._str then break end
			end
			return unpack(results)
		end,
		seek = function (s, whence, offset)
			if type(s._str) == "table" then
				s._str = table.concat(s._str)
			end
			local newpos
			if whence == "set" then
				newpos = offset + 1
			elseif whence == "cur" then
				newpos = s._pos + offset
			elseif whence == "end" then
				newpos = #s._str + 1 + offset
			end
			if newpos > 0 then
				s._pos = newpos
				return newpos - 1
			end
		end,
		setvbuf = nop,
		write = function (s, ...)
			s._lstr = nil
			if s._pos <= s._len then
				error("only append is supported for string writing ("..s._pos.."<="..s._len..")")
			end
			if type(s._str) ~= "table" then
				s._str = { s._str }
			end
			for _,arg in ipairs{...} do
				local astr = tostring(arg)
				s._str[#s._str+1] = astr
				s._pos = s._pos + #astr
				s._len = s._pos - 1
			end
		end,
		tostring = function (s)
			if type(s._str) == "table" then
				s._str = table.concat(s._str)
			end
			return s._str
		end,
	}
	if not mode:find("r") then
		iostr.read = nil
	elseif mode:find("a") then
		iostr.seek = nil
		iostr._pos = s._len + 1
	elseif not mode:find("[w+]") then
		iostr.write = nil
	end
	return setmetatable(iostr, {
		__tostring = function (t) return t:tostring() end,
	})
end

function serialize (var, file, indent)
	local getstring = false
	if not file then
		file = string.open("", "a")
		getstring = true
	end
	local function sortSet (t, comp)
		local sorted = {}
		for key in pairs(t) do
			sorted[#sorted + 1] = key
		end
		table.sort(sorted, comp)
		return sorted
	end
	local function dump (t, level)
		local indstr = string.rep("\t", level)
		local empty = true
		file:write("{")
		for _,k in ipairs(sortSet(t, function (a, b) if type(a) == "string" or type(b) == "string" then return tostring(a) < tostring(b) end return a < b end)) do
			if empty then
				empty = false
				file:write("\n")
			end
			local v = t[k]
			if type(k) ~= "string" then
				k = "[" .. tostring(k) .. "]"
			elseif tonumber(k:at(1)) then
				k = "[" .. string.format("%q", k) .. "]"
			end
			file:write(indstr, "\t", k, " = ")
			if type(v) == "table" then
				dump(v, level + 1)
			else
				if type(v) == "string" then
					v = string.format("%q", v)
				else
					v = tostring(v)
				end
				file:write(v, ",\n")
			end
		end
		if not empty then
			file:write(indstr)
		end
		file:write("}")
		if level > 0 then
			file:write(",")
		end
		file:write("\n")
	end
	dump(var, indent or 0)
	return getstring and tostring(file) or file
end
