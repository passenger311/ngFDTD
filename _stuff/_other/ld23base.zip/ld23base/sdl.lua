require "sdl_i"
local ffi = require "ffi"

ffi.cdef [[
enum {
	SDL_INIT_EVERYTHING = 0x0000ffff,
	SDL_OPENGL = 0x00000002,
};
]]

sdl = ffi.load("SDL")
return sdl
