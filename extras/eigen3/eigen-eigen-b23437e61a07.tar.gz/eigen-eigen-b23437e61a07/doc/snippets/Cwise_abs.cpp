Vector3d v(1,-2,-3);
cout << v.cwise().abs() << endl;
